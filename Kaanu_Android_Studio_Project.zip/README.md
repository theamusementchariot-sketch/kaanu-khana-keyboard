# Kàànu — Khana Android Keyboard (starter project)

This is an Android Studio project for an offline Khana keyboard with a word-suggestion strip and special Khana characters. It includes the extracted headwords from the supplied 2007 draft Kana-English dictionary.

## Build
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the debug APK on an Android phone.
5. Open Kàànu, tap Enable, enable it in Android Settings, then choose Kàànu from the input-method picker.

## Keyboard
- Standard QWERTY keys, space, delete and enter.
- Extra keys: ɛ ɔ ũ ã ɛ̀ ɔ̀ ɛ́ ɔ́ ŋ kp gb.
- Prefix suggestions from the included dictionary appear above the keys. Long-press a suggestion to view its dictionary meaning.
- No network permissions or network code are included.

## Important limitations
The source dictionary is explicitly a draft with incomplete entries and inconsistent tone/transcription conventions. Extracted meanings may contain example sentences and OCR/table-layout artifacts. This app preserves source spellings and should be improved through native-speaker review. Suggestions are prefix matching, not a trained language model.

This is source code, not a signed release APK. Building/signing and installing on a phone requires Android Studio or an Android build environment.
