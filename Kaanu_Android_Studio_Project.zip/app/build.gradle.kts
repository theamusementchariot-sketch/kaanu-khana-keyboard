plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "org.kaanu.keyboard"; compileSdk = 35
    defaultConfig { applicationId = "org.kaanu.keyboard"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
