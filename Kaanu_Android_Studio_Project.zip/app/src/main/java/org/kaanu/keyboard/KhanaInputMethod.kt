package org.kaanu.keyboard

import android.inputmethodservice.InputMethodService
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import org.json.JSONArray
import java.io.BufferedReader

class KhanaInputMethod : InputMethodService() {
 data class Entry(val word:String,val meaning:String)
 private var entries:List<Entry> = emptyList(); private lateinit var suggestions:LinearLayout; private lateinit var keys:LinearLayout
 override fun onCreate() { super.onCreate(); try { val s=assets.open("khana_dictionary.json").bufferedReader().use(BufferedReader::readText); val a=JSONArray(s); entries=(0 until a.length()).map { val o=a.getJSONObject(it); Entry(o.optString("word"), (o.optString("pos")+" "+o.optString("meaning")).trim()) } } catch (_:Exception){} }
 override fun onCreateInputView():View { val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,247,250)); setPadding(4,4,4,4) }
  suggestions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  root.addView(suggestions,LinearLayout.LayoutParams(-1,48)); keys=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; root.addView(keys)
  val rows=listOf("qwertyuiop","asdfghjkl","zxcvbnm")
  rows.forEach { line -> val r=LinearLayout(this); line.forEach { ch -> r.addView(key(ch.toString())) }; keys.addView(r) }
  val special=LinearLayout(this); listOf("ɛ","ɔ","ũ","ã","ɛ̀","ɔ̀","ɛ́","ɔ́","ŋ","kp","gb","Space","⌫","↵").forEach { special.addView(key(it)) }; keys.addView(special)
  updateSuggestions(""); return root
 }
 private fun key(label:String):View { val b=Button(this).apply { text=label; textSize=if(label.length>1)12f else 17f; isAllCaps=false; setPadding(0,0,0,0); minWidth=0; minimumWidth=0; setOnClickListener { val ic=currentInputConnection ?: return@setOnClickListener; when(label){"Space"->ic.commitText(" ",1);"⌫"->ic.deleteSurroundingText(1,0);"↵"->ic.commitText("\n",1);else->ic.commitText(label,1)}; refreshFromEditor() } }; return b }
 private fun refreshFromEditor(){ val ic=currentInputConnection ?: return; val before=ic.getTextBeforeCursor(80,0)?.toString().orEmpty(); updateSuggestions(before.substringAfterLast(' ')) }
 override fun onUpdateSelection(oldSelStart:Int,oldSelEnd:Int,newSelStart:Int,newSelEnd:Int,candidatesStart:Int,candidatesEnd:Int){super.onUpdateSelection(oldSelStart,oldSelEnd,newSelStart,newSelEnd,candidatesStart,candidatesEnd);refreshFromEditor()}
 private fun updateSuggestions(prefix:String){ if(!::suggestions.isInitialized)return; suggestions.removeAllViews(); val q=prefix.trim(); val matches=if(q.isEmpty()) entries.take(5) else entries.filter { it.word.startsWith(q,true) }.distinctBy{it.word}.take(5)
  matches.forEach { e -> val b=TextView(this).apply { text=e.word; textSize=16f; setTextColor(Color.rgb(23,52,91)); setTypeface(null,Typeface.BOLD); gravity=Gravity.CENTER; setPadding(10,4,10,4); setOnClickListener { val ic=currentInputConnection ?: return@setOnClickListener; val before=ic.getTextBeforeCursor(100,0)?.toString().orEmpty(); val token=before.substringAfterLast(' '); if(token.isNotEmpty()) ic.deleteSurroundingText(token.length,0); ic.commitText(e.word,1); refreshFromEditor() }; setOnLongClickListener { Toast.makeText(this@KhanaInputMethod,e.meaning,Toast.LENGTH_LONG).show(); true } }; suggestions.addView(b,LinearLayout.LayoutParams(0,-1,1f)) }
 }
}
